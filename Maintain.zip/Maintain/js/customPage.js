$('.glyphy').click(function (e) {
    if ($(e.target).is('input')) {
        $(this).find('.glyphicon').toggleClass('glyphicon-check glyphicon-unchecked');
        console.log( $(this).find('input').is(':checked') );
    }
});