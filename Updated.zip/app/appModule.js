var app=angular.module("myApp",[]);
app.controller("myCtrl",function($scope,countryData){
	var handleSuccess = function(data, status) {
	        $scope.JsonData = data;
	        $scope.usa=$scope.JsonData.countries.USA;
			$scope.aus=$scope.JsonData.countries.AUS;
			$scope.ca=$scope.JsonData.countries.CA;
			$scope.nz=$scope.JsonData.countries.NZ;
			getSelectedData();
	   	};
		countryData.getJsonData().success(handleSuccess);
		function getSelectedData(){
			//console.log($scope.usa);
			$scope.selected=false;
			$scope.countryDetails=function($event,index){
				/*$scope.myView=true;*/
				$scope.val=($event.target.id);
				console.log($scope.val);
				if($scope.val==""){
					$scope.selected=true;
				}
				/*if($scope.val==)*/
			}
		}
});