$(document).ready(function(){
	/*$('.glyphy').click(function(e) {
    if ($(e.target).is('input')) {
        $(this).find('.glyphicon').toggleClass('glyphicon-check glyphicon-unchecked');
        console.log( $(this).find('input').is(':checked') );
    }
	});*/
	var numberOfElmCount = 8/4;
	for(let i=1;i<=numberOfElmCount;i++){
		$(".pagination").append("<a class='page' href='#list1'>"+i+"</a>")
	}
	$("ul.list1 > li:hidden").slice(0, 4).show();
	$("ul.list2 > li:hidden").slice(0, 4).show();
	$(".page").click(function(){
		$(this).parent().parent().parent().find("ul li").hide();
		let pageCount = parseInt($(this).text())*4;
		let items = $(this).parent().parent().parent().find("ul > li:hidden");
		items.slice(pageCount-4, pageCount).show();
	})
	$('.arrowright').click(function(){
			$('.glyphyleftbox').each(function(){
				if($(this).is(':checked')){
				var parent = $(this).parent().html();
				$(".list2").append('<li class="selectrightboxes">'+parent+'<li>');
				$(this).parent().remove();
			}
		});
		
	});
	$('.arrowleft').click(function(){
			$('.glyphyrightbox').each(function(){
				if($(this).is(':checked')){
				var parent = $(this).parent().html();
				$(".list1").append('<li class="selectleftboxes">'+parent+'<li>');
				$(this).parent().remove();
			}
		});
		
	});
	/*var parentcount = 0;
	$('.arrowright').click(function(){
		$('.glyphyleftbox').each(function(){
				if($(this).is(':checked')){
				parentcount++;
			}	
		});
		var pagecount = Math.ceil(parentcount/8);
		for(var i=0;i<pagecount;i++){
			$('.list2').append('<div class="list '+(i+1)+'"></div>');
			for(var j=0;j<8;j++){
				var parent = $(this).parent().html();
				$(".list2 .list"+(i+1)).append('<li class="selectrightboxes">'+parent+'<li>');
				$(this).parent().remove();
			}
		}
		console.log(parentcount+ "" + pagecount);
	});*/
});