var app=angular.module("myApp",[]);
app.controller("myCtrl",function($scope,countryData){
	var handleSuccess = function(data, status) {
	        $scope.JsonData = data;
	        $scope.usa=$scope.JsonData.countries.USA;
			$scope.aus=$scope.JsonData.countries.AUS;
			$scope.ca=$scope.JsonData.countries.CA;
			$scope.nz=$scope.JsonData.countries.NZ;
			getSelectedData();
	   	};
		countryData.getJsonData().success(handleSuccess);
		function getSelectedData(){
			/*console.log($scope.usa);*/
			$scope.countryDetails=function(){
				
			}
		}
});