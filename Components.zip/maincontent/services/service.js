var customService = angular.module("myApp");
customService.factory("countryData", ["$http", function($http){

	return {
		getJsonData: function(){
			return $http.get("./countries.json");		
		}			
	}			
}]);